package com.example.hidevault

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** حالة الخزنة في الذاكرة فقط. لو العملية اتقفلت بترجع "مقفولة" تلقائي. */
object VaultState {
    @Volatile var unlocked = false

    /** بنرفعها قبل ما نفتح شاشة خارجية (اختيار صور / الإعدادات) عشان الخزنة متتقفلش. */
    @Volatile var externalFlow = false
}

/** تخزين مشفّر للـ PIN وقائمة التطبيقات المخفية. */
object Store {
    @Volatile private var prefs: SharedPreferences? = null
    @Volatile private var hiddenCache: Set<String>? = null

    private fun p(ctx: Context): SharedPreferences =
        prefs ?: synchronized(this) {
            prefs ?: run {
                val app = ctx.applicationContext
                val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
                EncryptedSharedPreferences.create(
                    app, "vault_prefs", key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            }.also { prefs = it }
        }

    // ---------- PIN ----------
    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun hasPin(ctx: Context) = p(ctx).contains("pin_hash")

    fun setPin(ctx: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(ctx).edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", hash(pin, salt))
            .apply()
    }

    fun checkPin(ctx: Context, pin: String): Boolean {
        val sp = p(ctx)
        val salt = Base64.decode(sp.getString("pin_salt", "") ?: return false, Base64.NO_WRAP)
        val expected = sp.getString("pin_hash", "") ?: return false
        return MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())
    }

    // ---------- حماية من التخمين: 5 محاولات غلط = انتظار 30 ثانية ----------
    fun lockoutRemainingMs(ctx: Context): Long =
        (p(ctx).getLong("lock_until", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    fun registerFailure(ctx: Context) {
        val sp = p(ctx)
        val fails = sp.getInt("fails", 0) + 1
        if (fails >= 5) {
            sp.edit().putInt("fails", 0).putLong("lock_until", System.currentTimeMillis() + 30_000L).apply()
        } else {
            sp.edit().putInt("fails", fails).apply()
        }
    }

    fun registerSuccess(ctx: Context) {
        p(ctx).edit().putInt("fails", 0).apply()
    }

    // ---------- التطبيقات المخفية (إشعاراتها بتتكتم) ----------
    fun hiddenApps(ctx: Context): Set<String> =
        hiddenCache ?: p(ctx).getStringSet("hidden", emptySet())!!.toSet().also { hiddenCache = it }

    fun setHidden(ctx: Context, pkg: String, hidden: Boolean) {
        val updated = hiddenApps(ctx).toMutableSet().apply { if (hidden) add(pkg) else remove(pkg) }
        p(ctx).edit().putStringSet("hidden", updated).apply()
        hiddenCache = updated
    }
}
