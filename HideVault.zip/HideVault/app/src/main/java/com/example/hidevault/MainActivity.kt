package com.example.hidevault

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {

    private var unlocked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // يمنع لقطات الشاشة ومعاينة التطبيق في قائمة التطبيقات الأخيرة
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            VaultApp(
                activity = this,
                unlocked = unlocked,
                onUnlock = { unlocked = true; VaultState.unlocked = true },
                onLock = { lock() }
            )
        }
    }

    private fun lock() {
        unlocked = false
        VaultState.unlocked = false
    }

    override fun onResume() {
        super.onResume()
        VaultState.externalFlow = false
    }

    override fun onStop() {
        super.onStop()
        if (!VaultState.externalFlow) lock()
    }
}
