package com.example.hidevault

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * بيكتم (يمسح) أي إشعار جاي من تطبيق في قائمة "المخفية"
 * طول ما الخزنة مقفولة. لما تفتح الخزنة الإشعارات بتظهر عادي.
 * محتاج إذن "الوصول للإشعارات" من إعدادات الموبايل.
 */
class HiddenAppsNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (VaultState.unlocked) return
        val hidden = Store.hiddenApps(applicationContext)
        try {
            activeNotifications?.filter { it.packageName in hidden }?.forEach { cancelNotification(it.key) }
        } catch (_: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (VaultState.unlocked) return
        if (sbn.packageName in Store.hiddenApps(applicationContext)) {
            cancelNotification(sbn.key)
        }
    }
}
