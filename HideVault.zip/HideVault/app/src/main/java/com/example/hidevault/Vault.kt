package com.example.hidevault

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID

/** خزنة الصور: كل صورة بتتشفّر (AES-256-GCM) وبتتخزن جوه مساحة التطبيق الخاصة بس. */
object Vault {

    private fun dir(ctx: Context) = File(ctx.filesDir, "vault").apply { mkdirs() }

    private fun enc(ctx: Context, file: File): EncryptedFile {
        val app = ctx.applicationContext
        val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedFile.Builder(
            app, file, key, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
    }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.name.endsWith(".vault") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun import(ctx: Context, uri: Uri): Boolean = try {
        val mime = ctx.contentResolver.getType(uri) ?: "image/jpeg"
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "jpg"
        val out = File(dir(ctx), "${UUID.randomUUID()}.$ext.vault")
        val input = ctx.contentResolver.openInputStream(uri)
        if (input == null) false else {
            input.use { src -> enc(ctx, out).openFileOutput().use { dst -> src.copyTo(dst) } }
            true
        }
    } catch (e: Exception) {
        false
    }

    private fun readBytes(ctx: Context, file: File): ByteArray =
        enc(ctx, file).openFileInput().use { it.readBytes() }

    /** بيفك التشفير في الذاكرة بس ويصغّر الصورة حسب الحاجة. */
    fun decode(ctx: Context, file: File, target: Int): Bitmap? = try {
        val bytes = readBytes(ctx, file)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(
            bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
        )
        val orientation = ExifInterface(ByteArrayInputStream(bytes))
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (bmp != null && degrees != 0f) {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
        } else bmp
    } catch (e: Exception) {
        null
    }

    /** بيرجّع الصورة للمعرض (Pictures/Restored) بعد فك التشفير. */
    fun export(ctx: Context, file: File): Boolean {
        val ext = file.name.removeSuffix(".vault").substringAfterLast('.')
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "image/jpeg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.$ext")
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Restored")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IllegalStateException()
            out.use { dst -> enc(ctx, file).openFileInput().use { it.copyTo(dst) } }
            true
        } catch (e: Exception) {
            ctx.contentResolver.delete(uri, null, null)
            false
        }
    }

    fun delete(file: File) = file.delete()
}
