package com.example.hidevault

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ======================= الجذر =======================

@Composable
fun VaultApp(activity: FragmentActivity, unlocked: Boolean, onUnlock: () -> Unit, onLock: () -> Unit) {
    MaterialTheme(colorScheme = appColors()) {
        Surface(Modifier.fillMaxSize()) {
            if (!unlocked) LockScreen(activity, onUnlock) else HomeScreen(onLock)
        }
    }
}

@Composable
private fun appColors(): ColorScheme {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    return when {
        Build.VERSION.SDK_INT >= 31 && dark -> dynamicDarkColorScheme(ctx)
        Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
}

// ======================= شاشة القفل =======================

private fun promptBiometric(activity: FragmentActivity, onSuccess: () -> Unit) {
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("فتح الخزنة")
        .setNegativeButtonText("استخدم الـ PIN")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .build()
    BiometricPrompt(
        activity,
        ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onSuccess()
            }
        }
    ).authenticate(info)
}

@Composable
fun LockScreen(activity: FragmentActivity, onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    val creating = remember { !Store.hasPin(ctx) }
    var pin by remember { mutableStateOf("") }
    var firstPin by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val canBio = remember {
        !creating && BiometricManager.from(ctx)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
    }

    LaunchedEffect(Unit) { if (canBio) promptBiometric(activity, onUnlocked) }

    fun submit() {
        if (pin.length < 4) {
            message = "الـ PIN لازم يكون 4 أرقام على الأقل"
            return
        }
        if (creating) {
            val first = firstPin
            when {
                first == null -> { firstPin = pin; pin = ""; message = "اكتب الـ PIN تاني للتأكيد" }
                first == pin -> { Store.setPin(ctx, pin); onUnlocked() }
                else -> { firstPin = null; pin = ""; message = "الرقمين مش متطابقين، ابدأ من تاني" }
            }
        } else {
            val wait = Store.lockoutRemainingMs(ctx)
            if (wait > 0) {
                pin = ""
                message = "حاول تاني بعد ${wait / 1000 + 1} ثانية"
                return
            }
            if (Store.checkPin(ctx, pin)) {
                Store.registerSuccess(ctx)
                onUnlocked()
            } else {
                Store.registerFailure(ctx)
                pin = ""
                message = "الـ PIN غلط"
            }
        }
    }

    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(16.dp))
        Text(
            if (creating) (if (firstPin == null) "اعمل PIN للخزنة" else "أكّد الـ PIN") else "ادخل الـ PIN",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pin = it },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true
        )
        message?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { submit() }) { Text(if (creating) "متابعة" else "فتح") }
        if (canBio) {
            TextButton(onClick = { promptBiometric(activity, onUnlocked) }) { Text("استخدم البصمة") }
        }
    }
}

// ======================= الشاشة الرئيسية =======================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onLock: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الخزنة") },
                actions = { TextButton(onClick = onLock) { Text("قفل") } }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Text("🖼") }, label = { Text("الصور") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Text("📱") }, label = { Text("التطبيقات") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) PhotosTab() else AppsTab()
        }
    }
}

// ======================= تبويب الصور =======================

@Composable
fun PhotosTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var version by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf(emptyList<File>()) }
    var busy by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(version) { files = withContext(Dispatchers.IO) { Vault.list(ctx) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(50)) { uris ->
        VaultState.externalFlow = false
        if (uris.isNotEmpty()) {
            busy = true
            scope.launch {
                val ok = withContext(Dispatchers.IO) { uris.count { Vault.import(ctx, it) } }
                busy = false
                version++
                Toast.makeText(
                    ctx,
                    "اتخبّى $ok من ${uris.size}. الصور الأصلية لسه في المعرض، امسحها بإيدك.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (files.isEmpty()) {
            Text(
                "مفيش صور لسه. دوس + عشان تخبّي صور.",
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(110.dp),
                contentPadding = PaddingValues(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(files, key = { it.name }) { f -> Thumb(f) { selected = f } }
            }
        }
        FloatingActionButton(
            onClick = {
                VaultState.externalFlow = true
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "إضافة صور") }
        if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
    }

    selected?.let { f ->
        PhotoViewer(f, onClose = { selected = null }, onChanged = { selected = null; version++ })
    }
}

@Composable
private fun Thumb(file: File, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { Vault.decode(ctx, file, 300)?.asImageBitmap() }
    }
    Box(Modifier.aspectRatio(1f).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun PhotoViewer(file: File, onClose: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmDelete by remember { mutableStateOf(false) }
    val bmp by produceState<ImageBitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { Vault.decode(ctx, file, 2048)?.asImageBitmap() }
    }
    val white = ButtonDefaults.textButtonColors(contentColor = Color.White)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, securePolicy = SecureFlagPolicy.SecureOn)
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    val b = bmp
                    if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    else CircularProgressIndicator()
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton(onClick = onClose, colors = white) { Text("إغلاق") }
                    TextButton(
                        colors = white,
                        onClick = {
                            scope.launch {
                                val ok = withContext(Dispatchers.IO) { Vault.export(ctx, file) }
                                if (ok) {
                                    Vault.delete(file)
                                    Toast.makeText(ctx, "رجعت للمعرض (Pictures/Restored)", Toast.LENGTH_SHORT).show()
                                    onChanged()
                                } else {
                                    Toast.makeText(ctx, "فشل استرجاع الصورة", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    ) { Text("استعادة للمعرض") }
                    TextButton(onClick = { confirmDelete = true }, colors = white) { Text("حذف") }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف نهائي؟") },
            text = { Text("الصورة هتتمسح من الخزنة ومش هتقدر ترجعها.") },
            confirmButton = {
                TextButton(onClick = { Vault.delete(file); confirmDelete = false; onChanged() }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}

// ======================= تبويب التطبيقات =======================

data class AppItem(val label: String, val pkg: String)

private fun isListenerEnabled(ctx: Context) =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun AppsTab() {
    val ctx = LocalContext.current
    var hidden by remember { mutableStateOf(Store.hiddenApps(ctx)) }
    var listenerOn by remember { mutableStateOf(isListenerEnabled(ctx)) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) listenerOn = isListenerEnabled(ctx)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val apps by produceState(emptyList<AppItem>()) { value = withContext(Dispatchers.IO) { loadApps(ctx) } }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (!listenerOn) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("لازم تدّي التطبيق إذن \"الوصول للإشعارات\" عشان يقدر يكتم إشعارات التطبيقات المخفية.")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            VaultState.externalFlow = true
                            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }) { Text("فتح الإعدادات") }
                    }
                }
            }
        }
        item {
            Text(
                "فعّل المفتاح لأي تطبيق عشان إشعاراته تتكتم طول ما الخزنة مقفولة، وتظهر لما تفتحها.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        items(apps, key = { it.pkg }) { app ->
            AppRow(app, app.pkg in hidden) { on ->
                Store.setHidden(ctx, app.pkg, on)
                hidden = Store.hiddenApps(ctx)
            }
        }
    }
}

@Composable
private fun AppRow(app: AppItem, hidden: Boolean, onToggle: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val icon = remember(app.pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                icon?.let { Image(it, null, Modifier.size(44.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(app.label, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (hidden) "الإشعارات مكتومة" else "الإشعارات عادية",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = hidden, onCheckedChange = onToggle)
            }
            Row {
                TextButton(onClick = {
                    ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let { ctx.startActivity(it) }
                }) { Text("فتح") }
                TextButton(onClick = {
                    VaultState.externalFlow = true
                    ctx.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, app.pkg)
                    )
                }) { Text("إعدادات إشعارات التطبيق") }
            }
        }
    }
}
